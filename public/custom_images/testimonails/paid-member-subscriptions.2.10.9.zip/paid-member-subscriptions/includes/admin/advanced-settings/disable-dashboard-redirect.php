<?php

add_filter( 'pms_enable_dashboard_redirect', '__return_false' );