<?php
/**
 * Hong Kong states
 *
 */

$pms_states['HK'] = array(
	'HONG KONG'       => __( 'Hong Kong Island', 'paid-member-subscriptions' ),
	'KOWLOON'         => __( 'Kowloon', 'paid-member-subscriptions' ),
	'NEW TERRITORIES' => __( 'New Territories', 'paid-member-subscriptions' )
);
