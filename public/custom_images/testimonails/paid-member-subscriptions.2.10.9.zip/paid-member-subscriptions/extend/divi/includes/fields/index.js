import MultipleCheckboxesWithIDs from './multiple-checkboxes-with-ids/multiple-checkboxes-with-ids';

export default [MultipleCheckboxesWithIDs];
