<?php echo do_shortcode( '[pms-account show_tabs="'.esc_attr( $settings->show_tabs ).'"]' ); ?>
