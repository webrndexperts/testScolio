<?php echo do_shortcode( '[pms-recover-password redirect_url="'.esc_url( $instance['pms_reset_redirect_url'] ).'"]'); ?>
