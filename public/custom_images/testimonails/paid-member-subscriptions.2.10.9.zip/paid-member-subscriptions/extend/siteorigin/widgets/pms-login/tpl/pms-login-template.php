<?php echo do_shortcode( '[pms-login redirect_url="'. esc_url( $instance['pms_login_redirect_url'] ).'" logout_redirect_url="'. esc_url( $instance['pms_logout_redirect_url'] ).'"]'); ?>
