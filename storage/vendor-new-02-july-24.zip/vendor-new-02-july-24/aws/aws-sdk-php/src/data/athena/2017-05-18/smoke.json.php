<?php
// This file was auto-generated from sdk-root/src/data/athena/2017-05-18/smoke.json
return [ 'version' => 1, 'defaultRegion' => 'us-west-2', 'testCases' => [ [ 'operationName' => 'ListNamedQueries', 'input' => [], 'errorExpectedFromService' => false, ], ],];
