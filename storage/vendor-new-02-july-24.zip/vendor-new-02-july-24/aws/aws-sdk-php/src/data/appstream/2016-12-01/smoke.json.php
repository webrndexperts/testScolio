<?php
// This file was auto-generated from sdk-root/src/data/appstream/2016-12-01/smoke.json
return [ 'version' => 1, 'defaultRegion' => 'us-west-2', 'testCases' => [ [ 'operationName' => 'DescribeStacks', 'input' => [], 'errorExpectedFromService' => false, ], ],];
