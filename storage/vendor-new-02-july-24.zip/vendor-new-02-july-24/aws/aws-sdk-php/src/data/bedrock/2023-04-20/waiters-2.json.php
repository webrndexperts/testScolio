<?php
// This file was auto-generated from sdk-root/src/data/bedrock/2023-04-20/waiters-2.json
return [ 'version' => 2, 'waiters' => [],];
