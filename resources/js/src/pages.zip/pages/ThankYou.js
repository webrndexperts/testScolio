import React,{useEffect} from 'react';
import ThankyouImg from '../images/Thank_you_gettingin_touch_EN.png';
import { useNavigate } from 'react-router-dom';
import ApiHook from '../components/CustomHooks/ApiHook';
import { scrollToTop } from '../components/Helper';
import { useLocation } from 'react-router-dom';

const ThankYou = () => {
    const navigate = useNavigate();
    const [currentLanguage, urlLanguage]=ApiHook();
    const { state } = useLocation();
    //  console.log("state",state);
    useEffect(()=>{
        scrollToTop();
       setTimeout(()=>{
         navigate(`${urlLanguage}/order`,{ state: state })
       },5000)
    },[currentLanguage,navigate])
    
  return (
    <div className="thank-you-page">
        <img src={ThankyouImg} alt=''/>
    </div>
  )
}

export default ThankYou
