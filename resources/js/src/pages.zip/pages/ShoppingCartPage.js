import React, { Fragment, useState, useEffect } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";
import CartItem from "../components/CartComponents/CartItem";
import Total from "../components/CartComponents/Total";
import { useForm } from "react-hook-form";
import { applyCoupon } from "../Api";
import { trimInputValues } from "../components/Helper";
import { useTranslation } from "react-i18next";
import ApiHook from "../components/CustomHooks/ApiHook";
import { BiCalendarHeart } from "react-icons/bi";
import { selectLanguage, setLanguage, selectUrlLanguage, setUrlLanguage } from '../reducers/languageSlice';
import TopBanner from '../components/TopBanner';

const ShoppingCartPage = () => {
	const { i18n, t } = useTranslation();
	const { lang } = useParams();
	const navigate = useNavigate();
	const [currentLanguage, urlLanguage] = ApiHook();
	const dispatch = useDispatch();
	const {
		register,
		reset,
		handleSubmit,
		formState: { errors },
	} = useForm();

	const { cart } = useSelector((state) => state.cart);
	const [couponCode, setCouponCode] = useState(1);
	const [error, setError] = useState("");
	const [msg, setMsg] = useState("");

	const applyCouponCode = (data) => {
		const trimData = trimInputValues(data);
		applyCoupon(trimData).then((response) => {
			setCouponCode(couponCode + 1);

			if (response.status) {
				sessionStorage.setItem("discountCoupon", JSON.stringify(response.data));
				setMsg(response.message);
			} else {
				setError(response.message);
			}
		}).catch((error) => {
			console.log("Error in rating data:", error);
		});
	};

	const navigateToOrder = () => {
		navigate(`${urlLanguage}/cart`);
	};

	useEffect(() => {
		if (typeof lang != 'undefined' && lang !== currentLanguage) {
			dispatch(setUrlLanguage(i18n.language));
			dispatch(setLanguage(i18n.language));
			navigateToOrder();
		}

		if(typeof lang == 'undefined') {
			dispatch(setUrlLanguage('en_US'));
			dispatch(setLanguage('en_US'));
			navigateToOrder();
		}
	}, [i18n.language, currentLanguage, dispatch, navigate, lang]);

	useEffect(() => {
		if(cart && !cart.length) {
			sessionStorage.removeItem('discountCoupon');
		}
	}, [cart])

	return (
		<Fragment>
			<TopBanner title={t("main-nav.CART")} />

			<div className="cart-page">
				<div className="container mt-5">
					<div className="row">
						{cart.length === 0 ? (
							<div className="entry-content rnd-test">
								<div className="woocommerce">
									<div className="wc-empty-cart-message">
										<div className="cart-empty woocommerce-info">
											<BiCalendarHeart />
											Your cart is currently empty.
										</div>
									</div>{" "}
									<p className="return-to-shop">
										<Link
											className="button wc-backward"
											to={`${urlLanguage}/shop`}
										>
											Return to shop
										</Link>
									</p>
								</div>
							</div>
						) : (
							<Fragment>
								<div className="col-sm-8">
									{cart?.map((item) => (
									<CartItem
									{...item}
									key={item.id}
									/>
									))}
									<div className="coupon">
										{msg && <div style={{ color: "green" }}>{msg}</div>}
										{error && <div style={{ color: "red" }}>{error}</div>}

										<label htmlFor="coupon_code">
											{t("CART12.APPLY COUPON CODE")}
										</label>

										<div className="custom_coupon_code">
											<form onSubmit={handleSubmit(applyCouponCode)}>
												<input
													{...register("coupon_code", { required: true })}
													type="text"
													name="coupon_code"
													className="input-text"
													id="coupon_code"
													placeholder="Coupon Code"
												/>
												{errors.coupon_code && (
													<p className="validations">
														Please enter your coupon code
													</p>
												)}
												<button
													type="submit"
													className="button"
													name="apply_coupon"
													value="Apply coupon"
												>
													{t("CART12.Apply Coupon Code")}
												</button>
											</form>
										</div>
									</div>
								</div>

								<Total couponCodes={couponCode} />
							</Fragment>
						)}
					</div>
				</div>
			</div>
		</Fragment>
	);
};

export default ShoppingCartPage;
