import React, { useState } from "react";
import { useForm } from "react-hook-form";

import { enquiry } from "../Api";
import { useTranslation } from "react-i18next";
import "react-awesome-slider/dist/styles.css";
import FormUser from "../images/form user.webp";
import FormEmail from "../images/form email.webp";
import FormNumber from "../images/form number.webp";
import FormCountry from "../images/form country.webp";
import ApiHook from "../components/CustomHooks/ApiHook";
import { trimInputValues } from "../components/Helper";
import ContactComponent from "../components/ContactComponent";

export default function FranForm() {
  const { t } = useTranslation();
  const [currentLanguage] = ApiHook();
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm();

  const generalEnquiry = (data) => {
    let formData = new FormData();

    formData.append('name', data.name);
    formData.append('email_address', data.email_address);
    formData.append('phone_number', data.phone_number);
    formData.append('country', data.country);
    formData.append('contact_enquiry', data.contact_enquiry);
    formData.append('description', data.description);
    formData.append('lang', currentLanguage);
    formData.append('form_type', "General Enquiry Home");
    formData.append('file', (data.file && data.file.length) ? data.file[0] : '');

    enquiry(formData);
    reset();
  };

  return (
    <div className="contact-form1">
      <div className="container ">
      <div className="row">
        <div className="col-sm-5">
          <div className="my-form">
            {/* main form */}

              <ContactComponent
                title={t("Contact")}
                col="6"
                labels={false}
                type="General Enquiry Home"
                optionPosition="other"
              />

          </div>
        </div>
      </div>
    </div>
    </div>
  );
}
