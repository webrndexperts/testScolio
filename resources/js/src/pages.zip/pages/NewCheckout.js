import React from 'react';
import { useTranslation } from "react-i18next";

const NewCheckout = (props) => {

    const { t } = useTranslation();

    return (
        <div className='checkout-new-page'>
           <div className='checkout-left'>
            <h6 className='express-text'>Express Checkout</h6>
            <div className='express-checkout-design'>
            <button type="submit">paypal</button>
            <button type="submit">card</button>
            </div>
            <p className='or-design'>or</p>
            <hr></hr>
            <div className='login-check'>
                <h2>Contact</h2>
                <a href='#'>Contact</a>
            </div>
            <input type="text" id="" name="" placeholder="Phone number or email" required/>
            <label>
          <input type="checkbox" checked="checked" name="sameadr"/> Shipping address same as billing
        </label>
        <div className='deliver-check'>
            <h2>Delivery</h2>
            <select name="country" id="country" required>
							<option value="">Country/Region</option>
							<option value="Canada">Canada</option>
							<option value="Not Canada">Not Canada</option>
						</select>
                        <div class="input_form">
            <div class="row">
              <div class="col-md-6">
                <div class="input_box_cart">
                  <input type="" placeholder="First name"/>
                </div>
              </div>
              <div class="col-md-6">
                <div class="input_box_cart">
                <input type="" placeholder="Last name"/>
                </div>
              </div>
            </div>
        </div>
        <div class="row">
              <div class="col-md-12">
                <div class="input_box_cart">
                <input type="" placeholder="Company (optional)"/>
                </div>
              </div>
           </div>
           <div class="row">
              <div class="col-md-12">
                <div class="input_box_cart">
                <input type="" placeholder="Street Address "/>
                </div>
              </div>
           </div>
           <div class="row">
              <div class="col-md-12">
                <div class="input_box_cart">
                <input type="" placeholder="Apartment, suite, unit, etc. (optional)"/>
                </div>
              </div>
           </div>
           <div class="row">
              <div class="col-md-4">
                <div class="input_box_cart">
                <input type="" placeholder="City"/>
                </div>
              </div>
              <div class="col-md-4">
                <div class="input_box_cart">
                <input type="text"placeholder="PIN code" class="form-control" id="zip" />
                </div>
              </div>
           </div>
        </div>
        </div>
        </div>
    )
}

export default NewCheckout;