import ForgetForm from './ForgetForm';

export {
	ForgetForm
}