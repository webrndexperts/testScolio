import React, { useState } from 'react';
import { useTranslation } from "react-i18next";
import { useForm } from "react-hook-form";

import { ForgetForm } from './components';
import { forgotPassword } from '../../Api';
import TopBanner from '../../components/TopBanner';

const ForgotPassword = (props) => {
	const [loader, setLoader] = useState(false);
	const [showThanks, setShowThanks] = useState(false);
	const [errorMsg, setErrorMsg] = useState('passwords.forgot.noUser');
	const [showError, setShowError] = useState(false);
	const { i18n, t } = useTranslation();

	const {
		register,
		handleSubmit,
		reset,
		formState: { errors },
	} = useForm();

  	const handleForgot = async (data) => {
  		setLoader(true);
  		let response = await forgotPassword(data);

  		// debugger;
	    setLoader(false);
	    // reset();
  	}

  	let formProps = { handleSubmit, handleForgot, loader, register, errors, t };

	return (
		<div className="forgot-page">
			<TopBanner title={t("passwords.forgot.title")} />

			<div className="row">
          		<div className="col-sm-6"></div>
          		<div className="col-sm-6 form-design">
          			{(showError) ? (
	          			<div class="alert alert-danger" role="alert">
						  	{t(errorMsg)}
						</div>
					) : null}

					<ForgetForm {...formProps} />
				</div>
			</div>
		</div>
	)
}

export default ForgotPassword;